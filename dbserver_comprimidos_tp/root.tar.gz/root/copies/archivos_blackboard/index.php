  1 <?php
  2 
  3 $servername = "IP_DBSERVER";
  4 $port = "3306";
  5 $username = "lcars";
  6 $password = "NCC1701D";
  7 $dbname = "ingenieria";
  8 
  9 
 10 
 11 $conn = new MySQLi ($servername, $username, $password, $dbname);
 12 
 13 // Error de conexión
 14 if ($conn->connect_error) {
 15   die("Error de conexion: " . $conn->connect_error);
 16 }
 17 
 18 $sql = "select alumnos.legajo 'legajo', 
 19                alumnos.apellido 'apellido', 
 20                alumnos.nombres 'nombre',
 21                 modulos.nom_modulo 'materia', 
 22                notas.nota 'nota'
 23         from   alumnos, 
 24                modulos, 
 25                notas 
 26         where  alumnos.legajo=notas.legajo 
 27            and modulos.cod_modulo = notas.cod_modulo;";
 28 
 29 if ($result = $conn->query($sql)) {
 30 
 31 while($row = $result->fetch_assoc()) {
 32     echo "legajo: " . $row["legajo"]. " -Nombre:  " . $row["nombre"]." " . $row["apellido"]. " | " . $r    ow["materia"]. " ---> " ."Nota: " . $row["nota"]."<br>";
 33   }
 34 }
 35 
 36 $conn->close();
 37 ?>

