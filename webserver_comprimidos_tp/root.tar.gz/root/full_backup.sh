#!/bin/bash


# todos los dias 0hs  /etc y /var/logs
# domingos 23hs /www_dir
# lunes, miercoles y viernes /db_dir
# a guardar en /backup_dir
# los nombres son [dir]_bkp_[date].tar.gz
#
# Origen y destino deben ser pasados como argumentos
# Validar que origen y destino existan
#
# Debe tener una opcion -h
#
# Debe ser agregado a cron
#

HELP='full_backup.sh INPUT_DIR OUTPUT_DIR
comprime INPUT_DIR y dejando el archivo en el OUTPUT_DIR con el formato [dir]_bkp_[date].tar.gz'

# Si la primer opcion es -h devolvemos help
if [[ $1 = '-h' ]]; then
  echo "$HELP"
  return 0
fi

INPUT_DIR=$1
OUTPUT_DIR=$2


# check si existe directorio a comprimir
if [[ ! -d "$INPUT_DIR" ]]; then
  echo "No existe el directorio de entrada: $INPUT_DIR"
  echo "$HELP"
  return 1
fi

# check si existe directorio de output
if [[ ! -d "$OUTPUT_DIR" ]]; then
  echo "No existe el directorio de salida: $OUTPUT_DIR"
  echo "$HELP"
  return 1
fi

# Eliminamos el trailing slash
TAR_FILE="${INPUT_DIR%/}"

# Componemos el nombre del tar,
# eliminando el path absoluto del input y dando el date
TAR_FILE="${TAR_FILE##*/}_bkp_$(date +%Y%m%d).tar.gz"

tar -zcf "${OUTPUT_DIR}/${TAR_FILE}" $INPUT_DIR | if [[ $? = 0 ]]; then echo "Compresion realizada exitosamente"; fi
return 0
